README datoteka

Proizvod: Prototip softverkog rje�enja Task Tracker
@Copyrights Axis Software Development 2014

1. Preduslovi
____________________________________________________
Na operativnom sistemu na kojem se pokre�e 
aplikacija potrebno je da je instaliran JRE.

Ukoliko JRE nije instaliran mo�ete ga preuzeti sa:
http://www.oracle.com/technetwork/java/javase/downloads/jre7-downloads-1880261.html


2. Otvaranje interfejsa
____________________________________________________

Potrebno je da napravite dvostruki klik na fajl
tt_protorip.jar, a nakon toga:

- Za otvaranje GUI-a za servisera u Prijavu je
potrebno unijeti:
Korisni�ko ime: serviser
�ifra: sifra

- Za otvaranje GUI-a za servisera u Prijavu je
potrebno unijeti:
Korisni�ko ime: racunovdstvo
�ifra: sifra

3. Neimplementirane funkcije
____________________________________________________

Sve funkcije koje nisu implementirane se mogu 
prepoznati jer se otavra MessageBox sa obavijesti o
o tome.

4. .pdf preuzimanja
____________________________________________________

Obzirom da nije implementiran rad sa .pdf 
dokumentima, tamo gdje je isti predvi�en se otvara
samo obavijest kako bi funkcionalnost trebala raditi